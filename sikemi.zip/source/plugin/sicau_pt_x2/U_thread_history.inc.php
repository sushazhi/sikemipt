<?php
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
} 
if(!isset($_GET['tid'])){
	showmessage("未指定帖子");
}else{
	$tid=$_GET['tid'];
}
$tid=$_GET['tid'];

$query=DB::query("select uid from ".DB::table('xbtit_history')." where tid={$tid} limit 15");
// $results=DB::fetch($query);
$users=array();
while($row=DB::fetch($query)){
	$users[]=$row['uid'];
    
}
if(empty($users)){
	$msg="<h4>你是第一个下载此资源的人哦！</h4>";
}else{
	foreach($users as $v=>$uid){
		include "xbt/config.inc.php";
   //     $queryun=DB::query("select username from ".DB::table('common_member')." where uid={$uid}");
   //     where($u=DB::fetch($queryun)){
   //     $us=$u['username'];      
//}
//foreach($us as $n=>$username){
		$msg.="<a href='home.php?mod=space&uid={$uid}&do=profile' title='{$username}' target='_blank'><img src='{$ucenter_url}avatar.php?uid={$uid}&size=small'/ style='padding-left:10px;padding-bottom:6px;float:left;'></a>";
//	}
    }
}

include template('downloaded_users_ajax', "sikemi","source/plugin/sikemi/templates");
?>
