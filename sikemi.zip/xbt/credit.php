<?php 
/*=============================================================================
#     FileName: credit.php
#         Desc:  
#       Author: osindex
#        Email: yaoiluo@gmail.com
#     HomePage: 
#      Version: 0.0.1
#   LastChange: 2013-12-27 18:45:44
#      History:
=============================================================================*/
    include './config.inc.php';
    include './include/db_mysql.class.php';
	error_reporting(E_ALL ^ E_NOTICE);
	$uid=($_GET["uid"]?$_GET["uid"]:$_POST["uid"]);//用户ID
    if(empty($uid)){
        echo "<script>alert('请登录!');window.history.back(-1);
        </script>";
	exit;
	}
    else{
		$callback = $_GET['callback'];
		$step=($_GET["step"]?$_GET["step"]:$_POST["step"]);
        $change=$_POST["change"];//确认按钮
        $extcreditsid="extcredits".($_GET["extcreditsid"]?$_GET["extcreditsid"]:$_POST["extcreditsid"]);//积分编号
        $type=$_POST["type"];//转换类型 流入/流出 流出=0 流入=1 不能为空
        $creditsnum=$_POST["creditsnum"];//转换数量 由插件换算
		$pid=($_POST["creditwhereid"]?$_POST["creditwhereid"]:'65728');//显示插件的名称||若没有则显示为扩展应用的收入/支出   
     
    //mysql
    $db = new dbstuff;
    $db->connect($dbhost,$dbuser,$dbpw,$dbname,$pconnect);

    //检查用户积分是否合格，低于1无法转化
/*    $credits =$db->query("SELECT credits FROM {$tablepre}common_member WHERE uid={$uid} limit 1");
    $credit = mysql_fetch_assoc($credits);
    if ($credit['credits'] < 1) {

        show_error("您的积分少于1，暂时无法同步积分，欢迎到外站灌水！",true); //true 开启正常运行

    };
*/
    //第一次仅查询 积分ID=extcreditsid
    if($step==(substr(md5($uid),2,10))){
    //如果是第一次查询
	//echo empty();
        //print_r($uid)
        //exit();
    $queryextcredits = $db->query("SELECT {$extcreditsid} FROM {$tablepre}common_member_count WHERE uid={$uid} limit 1");
    $queryextcredit = mysql_fetch_assoc($queryextcredits);
		/*if($queryextcredit[$extcreditsid] < 0){
			show_error("",true);
		}
		else{*/
    ret($queryextcredit[$extcreditsid]);
        //外站接收数据
		//}//end step1
	}
	elseif(!empty($step) && $creditsnum && isset($type)){
        //如果不是第一步，则更新积分
        ////有积分数据则更新
        //if($type){echo "null";}else{echo $type."0!=null";}
		if($creditsnum && ($type=='1')){
            /*$result=*/addtraffic($uid,$creditsnum,$extcreditsid,'');
             }
		if($creditsnum && ($type=='0')){
			/*$result=*/addtraffic($uid,$creditsnum,$extcreditsid,'-');
			}
       
    }

    }
    mysql_close();//end

    /*
     *
     *function
     * 
     *
     */

function show_error($message,$log) {
    if ($log){
    echo "ERROR-CODE:".strlen($message)."||$message";
    die();
	}
}

function ret($message) {
	global $callback;
	$arr=array('ret'=>$message);
 	echo $callback.'('.json_encode($arr).')';
 	exit();
    }

function addtraffic($uid,$creditsnum,$extcreditsid,$type){
    global $db,$tablepre,$pid;
    $extcredits1=$extcredits2=$extcredits3=$extcredits4=$extcredits5=$extcredits6=$extcredits7=$extcredits8=0;
    $temp=$extcreditsid;
    $$temp=$type.$creditsnum;
    $db->query("insert into {$tablepre}common_credit_log (uid,operation,relatedid,dateline,extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8) values ({$uid},'RCV',{$pid},UNIX_TIMESTAMP(),{$extcredits1},{$extcredits2},{$extcredits3},{$extcredits4},{$extcredits5},{$extcredits6},{$extcredits7},{$extcredits8})");
    $db->query("UPDATE {$tablepre}common_member_count set {$temp}={$temp}+{$$temp} WHERE uid={$uid} limit 1");
}


?>
