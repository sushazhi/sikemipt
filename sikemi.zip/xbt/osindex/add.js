function osindex_c(){
					var call,changc;
					if($('fromcredits_0').value=='3'){changc=$('exchangedesamount').value};
					call=$_G[member][extcredits1]*20+($_G[member][extcredits3]-$_G[member][extcredits4]-changc)/100;
					if(call<0){alert('将导致积分为负，不予兑换！');return false;}else{showWindow('credit', 'exchangeform', 'post');};
				}