<?php
echo "www";
?>
